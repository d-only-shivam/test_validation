package in.gov.uidai.controller.config;

import in.gov.uidai.db.DBConnection;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.sql.Connection;
import java.sql.SQLException;

@Configuration
public class DBBeanConfig {
    //Constructor based dependency injection
    private DBProperties dbProperties;

    public DBBeanConfig(DBProperties dbProperties) {
        this.dbProperties = dbProperties;
    }

    @Bean
    public Connection getConnection() throws SQLException, ClassNotFoundException {
        if(dbProperties.getDbPassword().equals("")){
            dbProperties.setDbPassword(null);
        }
        DBConnection dbConnection = new DBConnection(dbProperties.getDbUrl(), dbProperties.getDbUsername(), dbProperties.getDbPassword());
        Connection connection =  dbConnection.getConnection();
        return connection;
    }
}
