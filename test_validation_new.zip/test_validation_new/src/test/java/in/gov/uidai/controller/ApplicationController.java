package in.gov.uidai.controller;

import in.gov.uidai.db.DBConnection;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.sql.Connection;
import java.sql.SQLException;

@SpringBootApplication
public class ApplicationController {



    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        SpringApplication.run(ApplicationController.class, args);
    }


//        String EID = args[0];
//        System.out.println(EID);
//        String EID_FirstHalf =  EID.substring(0,14);
//        // String EID_SecondHalf = EID.substring(14,28);
//
//        EIDValidator eidValidator = new EidLatestValidatorImpl(){
//            public boolean IsEIDSecondHalfValid(String s){
//                return false;
//            }
//        };
//        Connection connection = DBConnection.getConnection();
//        boolean result = eidValidator.IsEIDFirstHalfValid(EID_FirstHalf, connection);
//        System.out.println(result);

    };

