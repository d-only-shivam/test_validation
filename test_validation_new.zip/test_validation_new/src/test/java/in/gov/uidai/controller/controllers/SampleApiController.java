package in.gov.uidai.controller.controllers;

import in.gov.uidai.db.DBConnection;
import in.gov.uidai.model.EIDValidator;
import in.gov.uidai.model.EIDValidatorImpl;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.SQLException;


@RestController
public class SampleApiController {

    Connection connection;

    //Constructor
    public SampleApiController(Connection connection) {
        // Injects connection dependency using constructor
        this.connection = connection;

    }

    @GetMapping("/getstatus")
    public String getStatus() {
        return "Success";
    }

    @PostMapping("/statuseid")
    public String getStatusOfEid(@RequestBody String eid) throws SQLException, ClassNotFoundException {
        System.out.println("Received eid :" + eid);
        if (eid.length() != 28) {
            return Boolean.toString(false);
        } else {
            EIDValidator eidValidation = new EIDValidatorImpl() {
                @Override
                public boolean IsEIDSecondHalfValid(String s) {
                    return true;
                }
            };
            // Connection connection = DBConnection.getConnection();
            boolean status = eidValidation.IsEIDFirstHalfValid(eid, connection);
            return Boolean.toString(status);
        }
    }
};



//@RestController
//public class Endpoints {
//
//    @PostMapping("/statuseid")
//    public String getStatus(@RequestBody String eid){
//        return "abc";
//
//    }
//}
